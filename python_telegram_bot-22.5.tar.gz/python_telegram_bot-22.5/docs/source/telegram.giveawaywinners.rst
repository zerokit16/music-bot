GiveawayWinners
===============

.. autoclass:: telegram.GiveawayWinners
    :members:
    :show-inheritance: