RevenueWithdrawalStatePending
=============================

.. autoclass:: telegram.RevenueWithdrawalStatePending
    :members:
    :show-inheritance:
