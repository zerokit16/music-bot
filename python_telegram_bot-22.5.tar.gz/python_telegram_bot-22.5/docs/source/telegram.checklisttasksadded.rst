ChecklistTasksAdded
===================

.. autoclass:: telegram.ChecklistTasksAdded
    :members:
    :show-inheritance:
