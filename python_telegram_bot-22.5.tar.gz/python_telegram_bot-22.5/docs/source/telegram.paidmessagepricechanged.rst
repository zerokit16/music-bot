PaidMessagePriceChanged
=======================

.. autoclass:: telegram.PaidMessagePriceChanged
    :members:
    :show-inheritance:
