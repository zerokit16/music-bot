SuggestedPostInfo
=================

.. autoclass:: telegram.SuggestedPostInfo
    :members:
    :show-inheritance:
