MenuButtonWebApp
================

.. autoclass:: telegram.MenuButtonWebApp
    :members:
    :show-inheritance: