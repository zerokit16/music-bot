TransactionPartnerChat
======================

.. autoclass:: telegram.TransactionPartnerChat
    :members:
    :show-inheritance:
