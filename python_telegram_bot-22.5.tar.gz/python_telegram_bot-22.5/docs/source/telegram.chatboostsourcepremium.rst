ChatBoostSourcePremium
======================

.. versionadded:: 20.8

.. autoclass:: telegram.ChatBoostSourcePremium
    :members:
    :show-inheritance: