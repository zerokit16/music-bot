Stickers
--------

The following methods and objects allow your bot to handle stickers and sticker sets.

.. toctree::
    :titlesonly:

    telegram.gift
    telegram.gifts
    telegram.inputsticker
    telegram.maskposition
    telegram.sticker
    telegram.stickerset
