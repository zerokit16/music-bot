BackgroundTypePattern
=====================

.. versionadded:: 21.2

.. autoclass:: telegram.BackgroundTypePattern
    :members:
    :show-inheritance: