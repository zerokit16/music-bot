ReactionTypePaid
================

.. autoclass:: telegram.ReactionTypePaid
    :members:
    :show-inheritance:
