StoryAreaTypeSuggestedReaction
==============================

.. autoclass:: telegram.StoryAreaTypeSuggestedReaction
    :members:
    :show-inheritance:
