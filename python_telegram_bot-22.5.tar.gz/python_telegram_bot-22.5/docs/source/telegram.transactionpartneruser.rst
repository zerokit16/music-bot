TransactionPartnerUser
======================

.. autoclass:: telegram.TransactionPartnerUser
    :members:
    :show-inheritance:
