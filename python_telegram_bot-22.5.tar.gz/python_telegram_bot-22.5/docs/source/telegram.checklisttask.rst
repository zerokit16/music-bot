ChecklistTask
=============

.. autoclass:: telegram.ChecklistTask
    :members:
    :show-inheritance:
