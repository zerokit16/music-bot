ForumTopicCreated
=================

.. autoclass:: telegram.ForumTopicCreated
    :members:
    :show-inheritance:
