StarTransaction
===============

.. autoclass:: telegram.StarTransaction
    :members:
    :show-inheritance:
