BackgroundFillSolid
===================

.. versionadded:: 21.2

.. autoclass:: telegram.BackgroundFillSolid
    :members:
    :show-inheritance: