InputStoryContentVideo
======================

.. autoclass:: telegram.InputStoryContentVideo
    :members:
    :show-inheritance:
