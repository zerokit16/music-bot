AcceptedGiftTypes
=================

.. autoclass:: telegram.AcceptedGiftTypes
    :members:
    :show-inheritance:
