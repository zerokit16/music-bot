SuggestedPostDeclined
=====================

.. autoclass:: telegram.SuggestedPostDeclined
    :members:
    :show-inheritance:
