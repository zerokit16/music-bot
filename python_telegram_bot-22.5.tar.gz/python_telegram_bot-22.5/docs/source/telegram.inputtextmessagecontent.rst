InputTextMessageContent
=======================

.. autoclass:: telegram.InputTextMessageContent
    :members:
    :show-inheritance:
