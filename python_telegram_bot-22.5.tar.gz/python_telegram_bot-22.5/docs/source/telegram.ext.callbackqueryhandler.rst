CallbackQueryHandler
====================

.. autoclass:: telegram.ext.CallbackQueryHandler
    :members:
    :show-inheritance:
