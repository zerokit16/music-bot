TransactionPartnerTelegramApi
=============================

.. autoclass:: telegram.TransactionPartnerTelegramApi
    :members:
    :show-inheritance:
