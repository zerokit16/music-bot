SuggestedPostParameters
=======================

.. autoclass:: telegram.SuggestedPostParameters
    :members:
    :show-inheritance:
