StoryAreaTypeWeather
====================

.. autoclass:: telegram.StoryAreaTypeWeather
    :members:
    :show-inheritance:
