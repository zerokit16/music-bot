LinkPreviewOptions
==================

.. autoclass:: telegram.LinkPreviewOptions
    :members:
    :show-inheritance:
