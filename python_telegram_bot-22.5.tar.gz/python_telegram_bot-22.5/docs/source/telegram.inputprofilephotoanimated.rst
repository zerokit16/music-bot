InputProfilePhotoAnimated
=========================

.. autoclass:: telegram.InputProfilePhotoAnimated
    :members:
    :show-inheritance: