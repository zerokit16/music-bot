SuggestedPostRefunded
=====================

.. autoclass:: telegram.SuggestedPostRefunded
    :members:
    :show-inheritance:
