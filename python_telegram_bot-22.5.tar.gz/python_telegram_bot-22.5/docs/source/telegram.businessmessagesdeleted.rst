BusinessMessagesDeleted
=======================

.. autoclass:: telegram.BusinessMessagesDeleted
    :members:
    :show-inheritance: