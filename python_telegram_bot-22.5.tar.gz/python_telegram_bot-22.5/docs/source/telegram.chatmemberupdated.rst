ChatMemberUpdated
=================

.. autoclass:: telegram.ChatMemberUpdated
    :members:
    :show-inheritance:
