RefundedPayment
===============

.. autoclass:: telegram.RefundedPayment
    :members:
    :show-inheritance:
