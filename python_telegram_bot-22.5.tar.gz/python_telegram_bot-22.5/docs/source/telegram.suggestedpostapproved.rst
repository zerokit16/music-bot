SuggestedPostApproved
=====================

.. autoclass:: telegram.SuggestedPostApproved
    :members:
    :show-inheritance:
