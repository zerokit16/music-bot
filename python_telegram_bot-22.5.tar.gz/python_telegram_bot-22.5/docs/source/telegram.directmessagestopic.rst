DirectMessagesTopic
===================

.. autoclass:: telegram.DirectMessagesTopic
    :members:
    :show-inheritance: