BusinessOpeningHoursInterval
============================

.. autoclass:: telegram.BusinessOpeningHoursInterval
    :members:
    :show-inheritance: