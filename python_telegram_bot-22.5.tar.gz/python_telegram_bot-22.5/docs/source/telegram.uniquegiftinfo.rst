UniqueGiftInfo
==============

.. autoclass:: telegram.UniqueGiftInfo
    :members:
    :show-inheritance:

