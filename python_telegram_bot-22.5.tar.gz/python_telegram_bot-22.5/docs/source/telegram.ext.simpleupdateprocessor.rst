SimpleUpdateProcessor
=====================

.. autoclass:: telegram.ext.SimpleUpdateProcessor
    :members:
    :show-inheritance: