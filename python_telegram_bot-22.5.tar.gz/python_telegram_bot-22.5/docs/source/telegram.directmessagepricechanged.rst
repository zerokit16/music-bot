DirectMessagePriceChanged
=========================

.. autoclass:: telegram.DirectMessagePriceChanged
    :members:
    :show-inheritance: