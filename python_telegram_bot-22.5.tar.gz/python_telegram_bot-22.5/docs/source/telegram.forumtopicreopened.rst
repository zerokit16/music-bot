ForumTopicReopened
==================

.. autoclass:: telegram.ForumTopicReopened
    :members:
    :show-inheritance:
