PollOption
==========

.. autoclass:: telegram.PollOption
    :members:
    :show-inheritance:
