InputChecklistTask
==================

.. autoclass:: telegram.InputChecklistTask
    :members:
    :show-inheritance:
