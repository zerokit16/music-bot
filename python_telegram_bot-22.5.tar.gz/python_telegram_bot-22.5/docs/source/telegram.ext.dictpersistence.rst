DictPersistence
===============

.. autoclass:: telegram.ext.DictPersistence
    :members:
    :show-inheritance:
