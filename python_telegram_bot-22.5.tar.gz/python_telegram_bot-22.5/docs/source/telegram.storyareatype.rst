StoryAreaType
=============

.. autoclass:: telegram.StoryAreaType
    :members:
    :show-inheritance:
